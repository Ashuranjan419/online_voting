package myproject;
public class VoteException extends Exception {
public VoteException() {
}
public VoteException(String message)
{
super(message);
}
}
