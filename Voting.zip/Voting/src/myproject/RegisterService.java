package myproject;
public class RegisterService {
public boolean addVoter(String fname,String lname,String gender,String pno,String prn,String password)
{
fname=fname.toLowerCase();
lname=lname.toLowerCase();
try{
new DAO().insertVoter(fname, lname, gender,pno, prn, password);
return true;
}
catch (VoteException ex) {
return false;
}
}
public boolean validateAdmin(String username, String password) {
try {
username = username.toLowerCase();
int a=new DAO().selectAdmin(username, password);
if(a==1)
return true;
else
return false;
}
catch (VoteException ex) {
return false;
}
}
public boolean validateVoter(String username, String password) {
try {
username = username.toLowerCase();
new DAO().selectUser(username, password);
return true;
}
catch (VoteException ex) {
return false;
}
}
}
