package myproject;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
public class DAO {
public Connection con;
public DAO() {
try {
con = DriverManager.getConnection("jdbc:mysql://localhost:3306/polling_system", "root", "root123");
System.out.println("connected");
} catch (SQLException ex) {
Logger.getLogger(DAO.class.getName()).log(Level.SEVERE, null, ex);
}
}
static {
try {
Class.forName("com.mysql.cj.jdbc.Driver");
System.out.println("loaded");
} catch (ClassNotFoundException ex) {
Logger.getLogger(DAO.class.getName()).log(Level.SEVERE, null, ex);
}
}
public void insertVoter(String fname,String lname,String gender,String pno,String prn,String password) throws VoteException
{
try {
int id = 0;
Statement st = con.createStatement();
String q= "SELECT * FROM registration ORDER BY id DESC LIMIT 1";
ResultSet rs = st.executeQuery(q);
if(rs.next()) {
id = rs.getInt("id");
id++;
}
String query = "INSERT INTO registration VALUES(?,?,?,?,?,?,?)";
PreparedStatement ps1 = con.prepareStatement(query);
ps1.setInt(1, id);
ps1.setString(2, fname);
ps1.setString(3, lname);
ps1.setString(4, gender);
ps1.setString(5, pno);
ps1.setString(6, prn);
ps1.setString(7, password);
ps1.executeUpdate();
} catch (SQLException ex) {
Logger.getLogger(DAO.class.getName()).log(Level.SEVERE, null, ex);
throw new VoteException();
} finally {
try {
con.close();
} catch (SQLException ex) {
Logger.getLogger(DAO.class.getName()).log(Level.SEVERE, null, ex);
}
}
}
public void selectUser(String prn,String password) throws VoteException {
try {
String query = "SELECT * FROM registration WHERE prn=? AND password=?";
PreparedStatement ps1 = con.prepareStatement(query);
con.createStatement();
ps1.setString(1, prn);
ps1.setString(2, password);
ResultSet rs = ps1.executeQuery();
if(!rs.next()) {
throw new VoteException();
}
} catch (SQLException ex) {
Logger.getLogger(DAO.class.getName()).log(Level.SEVERE, null, ex);
throw new VoteException();
} finally {
try {
con.close();
} catch (SQLException ex) {
Logger.getLogger(DAO.class.getName()).log(Level.SEVERE, null, ex);
}
}
}
public int selectAdmin(String prn,String password) throws VoteException {
try {
String query = "SELECT * FROM admin WHERE username=? AND password=?";
PreparedStatement ps1 = con.prepareStatement(query);
ps1.setString(1, prn);
ps1.setString(2, password);
ResultSet rs = ps1.executeQuery();
if(!rs.next()) {
return 0;
}
return 1;
} catch (SQLException ex) {
Logger.getLogger(DAO.class.getName()).log(Level.SEVERE, null, ex);
return 0;
} finally {
try {
con.close();
} catch (SQLException ex) {
Logger.getLogger(DAO.class.getName()).log(Level.SEVERE, null, ex);
}
}
}
public void insertVote(int vote) throws VoteException {
try {
String query = "INSERT INTO votes(optid) VALUES(?)";
PreparedStatement ps1 = con.prepareStatement(query);
//String query1 = "SELECT * FROM registration WHERE id=?";
//PreparedStatement ps2 = con.prepareStatement(query1);
ps1.setInt(1,vote);
//ps1.setString(2,query1);
ps1.executeUpdate();
} catch (SQLException ex) {
Logger.getLogger(DAO.class.getName()).log(Level.SEVERE, null, ex);
throw new VoteException();
} finally {
try {
con.close();
} catch (SQLException ex) {
Logger.getLogger(DAO.class.getName()).log(Level.SEVERE, null, ex);
}
}
}
public int getVotes(int opt_id)
{
try{
String query = "SELECT COUNT(*) FROM VOTES WHERE optid="+opt_id;
Statement st = con.createStatement();
ResultSet rs = st.executeQuery(query);
rs.next();
int nvotes= rs.getInt(1);
return nvotes;
}
catch (SQLException ex) {
Logger.getLogger(DAO.class.getName()).log(Level.SEVERE, null, ex);
return 0;
//throw new VoteException();
} finally {
try {
con.close();
} catch (SQLException ex) {
Logger.getLogger(DAO.class.getName()).log(Level.SEVERE, null, ex);
}
}
}
public String getWinner()
{
try{
String query = "SELECT * FROM votes GROUP BY optid ORDER BY count(*) DESC LIMIT 1";
Statement st = con.createStatement();
ResultSet rs = st.executeQuery(query);
rs.next();
int woptid= rs.getInt(1);
String query1 = "SELECT * FROM options WHERE optid = " + woptid;
ResultSet rs1 = st.executeQuery(query1);
rs1.next();
return rs1.getString("optname");
}
catch (SQLException ex) {
Logger.getLogger(DAO.class.getName()).log(Level.SEVERE, null, ex);
return null;
//throw new VoteException();
} finally {
try {
con.close();
} catch (SQLException ex) {
Logger.getLogger(DAO.class.getName()).log(Level.SEVERE, null, ex);
}
}
}
}
