package myproject;
public class ResultService {
public int retVotes(int opt_id)
{
int novotes = new DAO().getVotes(opt_id);
return novotes;
}
public String retWinner(){
String w_opt=new DAO().getWinner();
return w_opt;
}
}
